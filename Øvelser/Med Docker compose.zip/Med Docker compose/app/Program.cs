using System;
using MySql.Data.MySqlClient;

class Program
{
    static string connectionString = $"Server=localhost;Port=3306;Database=testdb;Uid=testuser;Pwd=testpass;";

    static void Main()
    {
        while (true)
        {
            Console.WriteLine("\nVælg en handling:");
            Console.WriteLine("1) Opret kunde");
            Console.WriteLine("2) Slet kunde");
            Console.WriteLine("3) Vis alle kunder");
            Console.WriteLine("0) Afslut");
            Console.Write("Valg: ");

            var input = Console.ReadLine();

            // Stop hvis vi ikke modtager noget input (typisk i non-interaktiv Docker)
            if (input == null)
            {
                Console.WriteLine("Ingen input modtaget – afslutter.");
                break;
            }

            switch (input.Trim())
            {
                case "1":
                    OpretKunde();
                    break;
                case "2":
                    SletKunde();
                    break;
                case "3":
                    VisKunder();
                    break;
                case "0":
                    Console.WriteLine("Farvel!");
                    return;
                default:
                    Console.WriteLine("Ugyldigt valg.");
                    break;
            }
        }
    }

    static void OpretKunde()
    {
        Console.Write("Indtast navn: ");
        var navn = Console.ReadLine();
        Console.Write("Indtast alder: ");
        var alderInput = Console.ReadLine();

        if (!int.TryParse(alderInput, out int alder))
        {
            Console.WriteLine("Ugyldigt tal for alder.");
            return;
        }

        using var conn = new MySqlConnection(connectionString);
        conn.Open();

        string sql = "INSERT INTO personer (navn, alder) VALUES (@navn, @alder);";
        using var cmd = new MySqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@navn", navn);
        cmd.Parameters.AddWithValue("@alder", alder);
        cmd.ExecuteNonQuery();

        Console.WriteLine("Kunde oprettet!");
    }

    static void SletKunde()
    {
        Console.Write("Indtast ID på kunde der skal slettes: ");
        var idInput = Console.ReadLine();

        if (!int.TryParse(idInput, out int id))
        {
            Console.WriteLine("Ugyldigt ID.");
            return;
        }

        using var conn = new MySqlConnection(connectionString);
        conn.Open();

        string sql = "DELETE FROM personer WHERE id = @id;";
        using var cmd = new MySqlCommand(sql, conn);
        cmd.Parameters.AddWithValue("@id", id);
        var result = cmd.ExecuteNonQuery();

        if (result > 0)
            Console.WriteLine("Kunde slettet.");
        else
            Console.WriteLine("Ingen kunde med det ID.");
    }

    static void VisKunder()
    {
        using var conn = new MySqlConnection(connectionString);
        conn.Open();

        string sql = "SELECT * FROM personer;";
        using var cmd = new MySqlCommand(sql, conn);
        using var reader = cmd.ExecuteReader();

        Console.WriteLine("\n-- Kundeoversigt --");
        while (reader.Read())
        {
            Console.WriteLine($"ID: {reader["id"]}, Navn: {reader["navn"]}, Alder: {reader["alder"]}");
        }
    }
}
