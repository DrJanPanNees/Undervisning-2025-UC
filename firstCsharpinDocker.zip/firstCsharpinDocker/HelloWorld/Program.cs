using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;

var builder = WebApplication.CreateBuilder(args);

// ---------- Configuration ----------
builder.Services.Configure<AppOptions>(
    builder.Configuration.GetSection("App"));

// ---------- Services ----------
builder.Services.AddSingleton<AppState>();
builder.Services.AddScoped<GreetingService>();

// ---------- Blazor ----------
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

// ---------- Minimal API ----------
builder.Services.AddEndpointsApiExplorer();

var app = builder.Build();

// ---------- Middleware ----------
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
}

app.UseStaticFiles();
app.UseAntiforgery();

// ---------- Minimal endpoint ----------
app.MapGet("/api/visits", (AppState state) =>
{
    return Results.Ok(new
    {
        visits = state.Visits,
        lastVisit = state.LastVisit
    });
});

// ---------- Blazor ----------
app.MapRazorComponents<HelloWorld.App>()
    .AddInteractiveServerRenderMode();

app.Run();


// ---------- Supporting classes ----------

public class AppState
{
    public int Visits { get; private set; }
    public DateTime? LastVisit { get; private set; }

    public void RegisterVisit()
    {
        Visits++;
        LastVisit = DateTime.Now;
    }
}

public class GreetingService
{
    private readonly AppOptions _options;
    private readonly AppState _state;

    public GreetingService(
        Microsoft.Extensions.Options.IOptions<AppOptions> options,
        AppState state)
    {
        _options = options.Value;
        _state = state;
    }

    public string GetGreeting(string name)
    {
        _state.RegisterVisit();

        return $"Hej {name}, velkommen til {_options.ApplicationName}. " +
               $"Du er besøgende nr. {_state.Visits}.";
    }
}

public class AppOptions
{
    public string ApplicationName { get; set; } = "Ukendt Blazor App";
}